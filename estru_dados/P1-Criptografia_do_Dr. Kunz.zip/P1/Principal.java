import java.util.Scanner;

public class Principal {
    
    public static boolean verifica(List<String> fechadura, List<String> chave) {        
        //inserir o código aqui
        boolean x = false;
        
        for (int i = 0; i < chave.size(); i++) {
            char c = chave.get(i).charAt(0);
            char f = fechadura.get(i).charAt(0);

            if (Character.isDigit(f) && c == f) {
                System.out.println("passou teste digito iguais");
                x = true; 
                continue;
                
            } else if (Character.isLetter(f) && c == f) {
                System.out.println("passou teste letras iguais");
                x = true; 
                continue;
                
            } else if (fechadura.get(i).equals("!") && Character.isLetter(c))  {
                x = true;
                continue;

            } else if (fechadura.get(i).equals("%") && Character.isDigit(c)){
                x = true;
                continue;
                
            } else{
                x = false;
                break;
            }
        }
        return(x);
    }

    public static List<String> montaLista(String entrada) {
        List<String> ret = new ArrayList<String>();        
        for (char i : entrada.toCharArray()) {            
            ret.add(String.valueOf(i));
        }
        return ret;
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> fechadura = montaLista(scanner.nextLine());        
        List<String> chave =  montaLista(scanner.nextLine());
        System.out.println(verifica(fechadura, chave));

    }
}