public class Retangulo implements IRetangulo{
    
    
}