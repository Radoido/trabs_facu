public class Tempo implements ITempo {
    
    
}