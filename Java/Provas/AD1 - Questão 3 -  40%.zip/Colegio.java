public class Colegio implements IColegio{
    
    
}