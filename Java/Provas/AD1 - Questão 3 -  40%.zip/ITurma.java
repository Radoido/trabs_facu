public interface ITurma {
    public String getNomeDisciplina();
    public double getMediaNota();
    public void setNomeDisciplina(String nomeDisciplina);
    public void setMediaNota(double mediaNota);
}
