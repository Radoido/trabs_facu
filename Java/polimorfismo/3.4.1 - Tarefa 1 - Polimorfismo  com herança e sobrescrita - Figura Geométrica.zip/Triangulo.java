public class Triangulo{
    
    
}