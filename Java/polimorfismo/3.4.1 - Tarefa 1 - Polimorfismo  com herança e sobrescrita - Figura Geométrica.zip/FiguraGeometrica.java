public class FiguraGeometrica {
    
    
}