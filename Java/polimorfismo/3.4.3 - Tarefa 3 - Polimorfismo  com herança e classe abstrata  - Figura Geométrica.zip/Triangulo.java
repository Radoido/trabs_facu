public class Triangulo {
    
    
}