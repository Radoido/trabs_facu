// Classe Jogador herda de Pessoa
class Jogador extends Pessoa {

    public Jogador(String nome, int idade, String posicao) {
    }

    public void exibirPosicao() {
    }
}