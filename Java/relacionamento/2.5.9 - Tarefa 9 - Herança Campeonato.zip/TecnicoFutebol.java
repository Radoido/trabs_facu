// Classe TecnicoFutebol herda de Tecnico
class TecnicoFutebol extends Tecnico {
    public TecnicoFutebol(String nome, int idade, String cargo, String estilo) {
    }

    public void exibirEstilo() {
    }
}