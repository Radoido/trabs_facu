// Classe Tecnico herda de Pessoa
class Tecnico extends Pessoa {

    public Tecnico(String nome, int idade, String cargo) {
    }

    public void exibirCargo() {
    }
}
