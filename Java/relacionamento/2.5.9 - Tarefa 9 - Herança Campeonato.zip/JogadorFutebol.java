// Classe JogadorFutebol herda de Jogador
class JogadorFutebol extends Jogador {

    public JogadorFutebol(String nome, int idade, String posicao, int numeroCamisa) {
    }

    public void exibirNumeroCamisa() {
    }
}