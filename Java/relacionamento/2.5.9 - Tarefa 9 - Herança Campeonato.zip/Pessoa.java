// Classe base Pessoa
class Pessoa {

    public Pessoa(String nome, int idade) {
    }

    public void exibirInformacoes() {
    }
}